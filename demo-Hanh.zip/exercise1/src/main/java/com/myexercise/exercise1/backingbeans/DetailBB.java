/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myexercise.exercise1.backingbeans;

import com.myexercise.exercise1.ejb.FoodDetail;
import com.myexercise.exercise1.ejb.FoodSB;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;

/**
 *
 * @author vhnhh
 */
@Named
@ViewScoped
public class DetailBB implements Serializable{
    @EJB
    FoodSB sb;
    
    @Inject
    FoodBB bb;
    
    private FoodDetail item;
    private String foodName;
    
    @PostConstruct
    public void init() {
        this.item = sb.findFoodDetailByFoodCd(bb.getFoodTmp().getFoodCd());
        this.foodName = bb.getFoodTmp().getFoodName();
    }
    
    public String convert(boolean flg) {
        if (flg) {
            return "Open";
        } else {
            return "Close";
        }
    }

    public FoodDetail getItem() {
        return item;
    }

    public void setItem(FoodDetail item) {
        this.item = item;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    
    
    
}
