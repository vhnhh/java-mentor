/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myexercise.exercise1.ejb;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author vhnhh
 */
public class FoodDetail implements Serializable{
    private String foodCd;
    private int lotNo;
    private String category;
    private Date expDate;
    private boolean status;

    public FoodDetail(String foodCd, int lotNo, String category, Date expDate, boolean status) {
        this.foodCd = foodCd;
        this.lotNo = lotNo;
        this.category = category;
        this.expDate = expDate;
        this.status = status;
    }

    public String getFoodCd() {
        return foodCd;
    }

    public void setFoodCd(String foodCd) {
        this.foodCd = foodCd;
    }

    public int getLotNo() {
        return lotNo;
    }

    public void setLotNo(int lotNo) {
        this.lotNo = lotNo;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Date getExpDate() {
        return expDate;
    }

    public void setExpDate(Date expDate) {
        this.expDate = expDate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (foodCd != null ? foodCd.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FoodDetail other = (FoodDetail) obj;
        return Objects.equals(this.foodCd, other.foodCd);
    }

    @Override
    public String toString() {
        return "FoodDetail{" + "foodCd=" + foodCd + ", lotNo=" + lotNo + ", category=" + category + ", expDate=" + expDate + ", status=" + status + '}';
    }

    

    
    
    
}
