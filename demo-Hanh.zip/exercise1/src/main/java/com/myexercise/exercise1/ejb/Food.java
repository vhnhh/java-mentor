/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myexercise.exercise1.ejb;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 *
 * @author vhnhh
 */
public class Food implements Serializable{
    private String foodCd;
    private String foodName;
    private BigDecimal price;

    public Food(String foodCd, String foodName, BigDecimal price) {
        this.foodCd = foodCd;
        this.foodName = foodName;
        this.price = price;
    }

    public String getFoodCd() {
        return foodCd;
    }

    public void setFoodCd(String foodCd) {
        this.foodCd = foodCd;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (foodCd != null ? foodCd.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Food other = (Food) obj;
        return Objects.equals(this.foodCd, other.foodCd);
    }

    @Override
    public String toString() {
        return "Food{" + "foodCd=" + foodCd + ", foodName=" + foodName + ", price=" + price + '}';
    }
}
