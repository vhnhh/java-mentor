/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myexercise.exercise1.ejb;

import jakarta.annotation.PostConstruct;
import jakarta.ejb.Stateless;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author vhnhh
 */
@Stateless
public class FoodSB {
    private List<Food> foodList;
    private List<FoodDetail> detailList;
    
    @PostConstruct
    public void init() {
        foodList = new ArrayList<>();
        foodList.add(new Food("CT001-A01", "Tiramisu", new BigDecimal("2500")));
        foodList.add(new Food("CM002-A01", "Mousse", new BigDecimal("2800")));
        foodList.add(new Food("FA003-A01", "Apple", new BigDecimal("500")));
        foodList.add(new Food("MB004-A01", "Beef", new BigDecimal("4500")));
        foodList.add(new Food("BB005-A01", "Banh-mi-thit", new BigDecimal("1000")));
        detailList = new ArrayList<>();
        detailList.add(new FoodDetail("CT001-A01", 1, "Cake", java.sql.Date.valueOf("2025-12-24"), true));
        detailList.add(new FoodDetail("CM002-A01", 2, "Cake", java.sql.Date.valueOf("2025-4-24"), false));
        detailList.add(new FoodDetail("FA003-A01", 4, "Fruit", java.sql.Date.valueOf("2025-12-25"), true));
        detailList.add(new FoodDetail("MB004-A01", 5, "Meat", java.sql.Date.valueOf("2025-12-26"), true));
        detailList.add(new FoodDetail("BB005-A01", 1, "Break", java.sql.Date.valueOf("2025-12-27"), true));
                    System.out.println(">>>>>>>>>>>>> DEBUG        foodList:   " + foodList.size());
                    System.out.println(">>>>>>>>>>>>> DEBUG        detailList:   " + detailList.size());
    }
    
    public FoodDetail findFoodDetailByFoodCd(String foodCd) {
        return detailList.stream().filter(f -> f.getFoodCd().equals(foodCd)).findFirst().orElse(null);
    }
    
    public List<Food> getFoodList() {
        return foodList;
    }
    
    
}
