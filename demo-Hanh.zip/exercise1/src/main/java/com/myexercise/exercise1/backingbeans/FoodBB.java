/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myexercise.exercise1.backingbeans;

import com.myexercise.exercise1.ejb.Food;
import com.myexercise.exercise1.ejb.FoodSB;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author vhnhh
 */
@Named
@SessionScoped
public class FoodBB implements Serializable{
    @EJB
    FoodSB sb;
    
    private List<Food> list;
    private Food foodTmp;
    
    @PostConstruct
    public void init() {
        this.list = sb.getFoodList();
    }
    
    public String detail(Food tmp) {
        this.foodTmp = tmp;
        return "detail.xhtml";
    }

    public List<Food> getList() {
        return list;
    }

    public void setList(List<Food> list) {
        this.list = list;
    }

    public Food getFoodTmp() {
        return foodTmp;
    }

    public void setFoodTmp(Food foodTmp) {
        this.foodTmp = foodTmp;
    }
}
